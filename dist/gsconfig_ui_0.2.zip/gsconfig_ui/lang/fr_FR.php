<?php 

	$i18n = array(
		'PLUGIN_NAME' => 'GSconfig UI',
		'PLUGIN_DESCR' => 'Interface pour gsconfig.php. Changez des paramètres de configuration directement à partir de GS CMS. Requiert <a href="http://get-simple.info/extend/plugin/gs-custom-settings/913/">GS Custom Settings</a>',
		'GEN_SALT' => 'Générer clé de hachage',
		'CUSTOM_TOOLBAR' => 'Générateur barre d\'outils CKEditor'
	);