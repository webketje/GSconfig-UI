<?php 

	$i18n = array(
		'PLUGIN_NAME' => 'Настройки GSconfig',
		'PLUGIN_DESCR' => 'Настройки gsconfig.php. Требуется установить плагин <a href=\"http://get-simple.info/extend/plugin/gs-custom-settings/913/\">GS Custom Settings</a>',
		'GEN_SALT' => 'Генерировать Salt',
		'CUSTOM_TOOLBAR' => 'Ваши настройки редактора CKEditor'
	);