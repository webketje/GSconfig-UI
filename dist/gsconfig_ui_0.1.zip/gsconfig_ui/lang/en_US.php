<?php 

	$i18n = array(
		'PLUGIN_NAME' => 'GSconfig UI',
		'PLUGIN_DESCR' => 'UI shim for gsconfig.php. Tweak config settings directly from GS CMS. Requires <a href="#">GS Custom Settings</a>',
		'GEN_SALT' => 'Generate salt',
		'CUSTOM_TOOLBAR' => 'Custom toolbar builder'
	);